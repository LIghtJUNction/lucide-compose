package io.github.yumeyucca.lucide

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

val Lucide.ArrowBigRightDash: ImageVector
    get() {
        if (_ArrowBigRightDash != null) {
            return _ArrowBigRightDash!!
        }
        _ArrowBigRightDash = ImageVector.Builder(
            name = "ArrowBigRightDash",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(11f, 9f)
                arcToRelative(1f, 1f, 0f, isMoreThanHalf = false, isPositiveArc = false, 1f, -1f)
                verticalLineTo(4.707f)
                arcToRelative(0.707f, 0.707f, 0f, isMoreThanHalf = false, isPositiveArc = true, 1.207f, -0.5f)
                lineToRelative(6.94f, 6.94f)
                arcToRelative(1.207f, 1.207f, 0f, isMoreThanHalf = false, isPositiveArc = true, 0f, 1.707f)
                lineToRelative(-6.94f, 6.94f)
                arcToRelative(0.707f, 0.707f, 0f, isMoreThanHalf = false, isPositiveArc = true, -1.207f, -0.5f)
                verticalLineTo(16f)
                arcToRelative(1f, 1f, 0f, isMoreThanHalf = false, isPositiveArc = false, -1f, -1f)
                horizontalLineTo(9f)
                arcToRelative(1f, 1f, 0f, isMoreThanHalf = false, isPositiveArc = true, -1f, -1f)
                verticalLineToRelative(-4f)
                arcToRelative(1f, 1f, 0f, isMoreThanHalf = false, isPositiveArc = true, 1f, -1f)
                close()
            }
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(4f, 9f)
                verticalLineToRelative(6f)
            }
        }.build()

        return _ArrowBigRightDash!!
    }

@Suppress("ObjectPropertyName")
private var _ArrowBigRightDash: ImageVector? = null
