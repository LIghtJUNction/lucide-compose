package io.github.yumeyucca.lucide

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

val Lucide.ChevronsDownUp: ImageVector
    get() {
        if (_ChevronsDownUp != null) {
            return _ChevronsDownUp!!
        }
        _ChevronsDownUp = ImageVector.Builder(
            name = "ChevronsDownUp",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveToRelative(7f, 20f)
                lineToRelative(5f, -5f)
                lineToRelative(5f, 5f)
            }
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveToRelative(7f, 4f)
                lineToRelative(5f, 5f)
                lineToRelative(5f, -5f)
            }
        }.build()

        return _ChevronsDownUp!!
    }

@Suppress("ObjectPropertyName")
private var _ChevronsDownUp: ImageVector? = null
