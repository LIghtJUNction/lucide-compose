package io.github.yumeyucca.lucide

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

val Lucide.BoneFracture: ImageVector
    get() {
        if (_BoneFracture != null) {
            return _BoneFracture!!
        }
        _BoneFracture = ImageVector.Builder(
            name = "BoneFracture",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(14f, 4.5f)
                arcToRelative(1f, 1f, 0f, isMoreThanHalf = false, isPositiveArc = true, 5f, 0f)
                arcToRelative(0.5f, 0.5f, 0f, isMoreThanHalf = false, isPositiveArc = false, 0.5f, 0.5f)
                arcToRelative(1f, 1f, 0f, isMoreThanHalf = false, isPositiveArc = true, 0f, 5f)
                curveToRelative(-0.81f, 0f, -1.8f, -0.7f, -2.5f, 0f)
                lineToRelative(-1.958f, 1.957f)
                arcToRelative(0.15f, 0.15f, 0f, isMoreThanHalf = false, isPositiveArc = true, -0.252f, -0.072f)
                lineToRelative(-0.493f, -2.07f)
                arcToRelative(0.15f, 0.15f, 0f, isMoreThanHalf = false, isPositiveArc = false, -0.111f, -0.112f)
                lineToRelative(-2.072f, -0.494f)
                arcToRelative(0.15f, 0.15f, 0f, isMoreThanHalf = false, isPositiveArc = true, -0.072f, -0.252f)
                lineTo(14f, 7f)
                curveToRelative(0.7f, -0.7f, 0f, -1.69f, 0f, -2.5f)
            }
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveToRelative(16f, 20f)
                lineToRelative(-1f, -2f)
            }
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveToRelative(20f, 16f)
                lineToRelative(-2f, -1f)
            }
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveToRelative(4f, 8f)
                lineToRelative(2f, 1f)
            }
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveToRelative(8f, 4f)
                lineToRelative(1f, 2f)
            }
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(9.698f, 14.19f)
                arcToRelative(0.15f, 0.15f, 0f, isMoreThanHalf = false, isPositiveArc = false, 0.112f, 0.112f)
                lineToRelative(2.074f, 0.489f)
                arcToRelative(0.15f, 0.15f, 0f, isMoreThanHalf = false, isPositiveArc = true, 0.072f, 0.252f)
                lineTo(10f, 17f)
                curveToRelative(-0.7f, 0.7f, 0f, 1.69f, 0f, 2.5f)
                arcToRelative(1f, 1f, 0f, isMoreThanHalf = false, isPositiveArc = true, -5f, 0f)
                arcToRelative(0.495f, 0.495f, 0f, isMoreThanHalf = false, isPositiveArc = false, -0.5f, -0.5f)
                arcToRelative(1f, 1f, 0f, isMoreThanHalf = false, isPositiveArc = true, 0f, -5f)
                curveToRelative(0.81f, 0f, 1.8f, 0.7f, 2.5f, 0f)
                lineToRelative(1.956f, -1.957f)
                arcToRelative(0.15f, 0.15f, 0f, isMoreThanHalf = false, isPositiveArc = true, 0.252f, 0.072f)
                close()
            }
        }.build()

        return _BoneFracture!!
    }

@Suppress("ObjectPropertyName")
private var _BoneFracture: ImageVector? = null
