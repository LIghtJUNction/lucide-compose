package io.github.yumeyucca.lucide

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

val Lucide.Carrot: ImageVector
    get() {
        if (_Carrot != null) {
            return _Carrot!!
        }
        _Carrot = ImageVector.Builder(
            name = "Carrot",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(15f, 16f)
                arcToRelative(1f, 1f, 0f, isMoreThanHalf = false, isPositiveArc = false, -7f, -7f)
                quadToRelative(-4f, 4f, -5.987f, 12.385f)
                arcToRelative(0.5f, 0.5f, 0f, isMoreThanHalf = false, isPositiveArc = false, 0.602f, 0.602f)
                quadTo(11f, 20f, 15f, 16f)
                lineToRelative(-3f, -3f)
            }
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(15f, 9f)
                quadToRelative(4f, 4f, 7f, 0f)
                quadToRelative(-3f, -4f, -7f, 0f)
                quadToRelative(4f, -4f, 0f, -7f)
                quadToRelative(-4f, 3f, 0f, 7f)
            }
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveToRelative(8f, 15f)
                lineToRelative(-2.58f, -2.58f)
            }
        }.build()

        return _Carrot!!
    }

@Suppress("ObjectPropertyName")
private var _Carrot: ImageVector? = null
