package io.github.yumeyucca.lucide

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

val Lucide.ArrowBigUpDash: ImageVector
    get() {
        if (_ArrowBigUpDash != null) {
            return _ArrowBigUpDash!!
        }
        _ArrowBigUpDash = ImageVector.Builder(
            name = "ArrowBigUpDash",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(14f, 16f)
                arcToRelative(1f, 1f, 0f, isMoreThanHalf = false, isPositiveArc = false, 1f, -1f)
                verticalLineToRelative(-2f)
                arcToRelative(1f, 1f, 0f, isMoreThanHalf = false, isPositiveArc = true, 1f, -1f)
                horizontalLineToRelative(3.293f)
                arcToRelative(0.707f, 0.707f, 0f, isMoreThanHalf = false, isPositiveArc = false, 0.5f, -1.207f)
                lineToRelative(-6.939f, -6.939f)
                arcToRelative(1.207f, 1.207f, 0f, isMoreThanHalf = false, isPositiveArc = false, -1.708f, 0f)
                lineToRelative(-6.94f, 6.94f)
                arcToRelative(0.707f, 0.707f, 0f, isMoreThanHalf = false, isPositiveArc = false, 0.5f, 1.206f)
                horizontalLineTo(8f)
                arcToRelative(1f, 1f, 0f, isMoreThanHalf = false, isPositiveArc = true, 1f, 1f)
                verticalLineToRelative(2f)
                arcToRelative(1f, 1f, 0f, isMoreThanHalf = false, isPositiveArc = false, 1f, 1f)
                close()
            }
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(9f, 20f)
                horizontalLineToRelative(6f)
            }
        }.build()

        return _ArrowBigUpDash!!
    }

@Suppress("ObjectPropertyName")
private var _ArrowBigUpDash: ImageVector? = null
