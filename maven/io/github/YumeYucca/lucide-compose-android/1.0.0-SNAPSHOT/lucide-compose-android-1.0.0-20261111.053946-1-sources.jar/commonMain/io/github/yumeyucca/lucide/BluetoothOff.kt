package io.github.yumeyucca.lucide

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

val Lucide.BluetoothOff: ImageVector
    get() {
        if (_BluetoothOff != null) {
            return _BluetoothOff!!
        }
        _BluetoothOff = ImageVector.Builder(
            name = "BluetoothOff",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveToRelative(17f, 17f)
                lineToRelative(-5f, 5f)
                verticalLineTo(12f)
                lineToRelative(-5f, 5f)
            }
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveToRelative(2f, 2f)
                lineToRelative(20f, 20f)
            }
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(14.5f, 9.5f)
                lineTo(17f, 7f)
                lineToRelative(-5f, -5f)
                verticalLineToRelative(4.5f)
            }
        }.build()

        return _BluetoothOff!!
    }

@Suppress("ObjectPropertyName")
private var _BluetoothOff: ImageVector? = null
