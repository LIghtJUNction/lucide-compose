package io.github.yumeyucca.lucide

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

val Lucide.CircleOff: ImageVector
    get() {
        if (_CircleOff != null) {
            return _CircleOff!!
        }
        _CircleOff = ImageVector.Builder(
            name = "CircleOff",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveToRelative(2f, 2f)
                lineToRelative(20f, 20f)
            }
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(8.35f, 2.69f)
                arcTo(10f, 10f, 0f, isMoreThanHalf = false, isPositiveArc = true, 21.3f, 15.65f)
            }
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(19.08f, 19.08f)
                arcTo(10f, 10f, 0f, isMoreThanHalf = true, isPositiveArc = true, 4.92f, 4.92f)
            }
        }.build()

        return _CircleOff!!
    }

@Suppress("ObjectPropertyName")
private var _CircleOff: ImageVector? = null
