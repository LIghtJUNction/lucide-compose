package io.github.yumeyucca.lucide

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

val Lucide.ChevronsDown: ImageVector
    get() {
        if (_ChevronsDown != null) {
            return _ChevronsDown!!
        }
        _ChevronsDown = ImageVector.Builder(
            name = "ChevronsDown",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveToRelative(7f, 6f)
                lineToRelative(5f, 5f)
                lineToRelative(5f, -5f)
            }
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveToRelative(7f, 13f)
                lineToRelative(5f, 5f)
                lineToRelative(5f, -5f)
            }
        }.build()

        return _ChevronsDown!!
    }

@Suppress("ObjectPropertyName")
private var _ChevronsDown: ImageVector? = null
