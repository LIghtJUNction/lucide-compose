package io.github.yumeyucca.lucide

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

val Lucide.ChevronsLeft: ImageVector
    get() {
        if (_ChevronsLeft != null) {
            return _ChevronsLeft!!
        }
        _ChevronsLeft = ImageVector.Builder(
            name = "ChevronsLeft",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveToRelative(11f, 17f)
                lineToRelative(-5f, -5f)
                lineToRelative(5f, -5f)
            }
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveToRelative(18f, 17f)
                lineToRelative(-5f, -5f)
                lineToRelative(5f, -5f)
            }
        }.build()

        return _ChevronsLeft!!
    }

@Suppress("ObjectPropertyName")
private var _ChevronsLeft: ImageVector? = null
