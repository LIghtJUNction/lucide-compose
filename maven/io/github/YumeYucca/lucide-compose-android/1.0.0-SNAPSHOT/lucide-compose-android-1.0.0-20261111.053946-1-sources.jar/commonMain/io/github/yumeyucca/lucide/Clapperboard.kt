package io.github.yumeyucca.lucide

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.path
import androidx.compose.ui.unit.dp

val Lucide.Clapperboard: ImageVector
    get() {
        if (_Clapperboard != null) {
            return _Clapperboard!!
        }
        _Clapperboard = ImageVector.Builder(
            name = "Clapperboard",
            defaultWidth = 24.dp,
            defaultHeight = 24.dp,
            viewportWidth = 24f,
            viewportHeight = 24f
        ).apply {
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveToRelative(12.296f, 3.464f)
                lineToRelative(3.02f, 3.956f)
            }
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(20.2f, 6f)
                lineTo(3f, 11f)
                lineToRelative(-0.9f, -2.4f)
                curveToRelative(-0.3f, -1.1f, 0.3f, -2.2f, 1.3f, -2.5f)
                lineToRelative(13.5f, -4f)
                curveToRelative(1.1f, -0.3f, 2.2f, 0.3f, 2.5f, 1.3f)
                close()
            }
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveTo(3f, 11f)
                horizontalLineToRelative(18f)
                verticalLineToRelative(8f)
                arcToRelative(2f, 2f, 0f, isMoreThanHalf = false, isPositiveArc = true, -2f, 2f)
                horizontalLineTo(5f)
                arcToRelative(2f, 2f, 0f, isMoreThanHalf = false, isPositiveArc = true, -2f, -2f)
                close()
            }
            path(
                stroke = SolidColor(Color.Black),
                strokeLineWidth = 2f,
                strokeLineCap = StrokeCap.Round,
                strokeLineJoin = StrokeJoin.Round
            ) {
                moveToRelative(6.18f, 5.276f)
                lineToRelative(3.1f, 3.899f)
            }
        }.build()

        return _Clapperboard!!
    }

@Suppress("ObjectPropertyName")
private var _Clapperboard: ImageVector? = null
